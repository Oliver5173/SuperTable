# FullCalendar Scheduler [![Build Status](https://travis-ci.org/fullcalendar/fullcalendar-scheduler.svg?branch=master)](https://travis-ci.org/fullcalendar/fullcalendar-scheduler)

A premium add-on to [FullCalendar](http://fullcalendar.io/) for displaying events and resources.

- [Project website and demos](http://fullcalendar.io/scheduler/)
- [License](http://fullcalendar.io/scheduler/license/)
- [Changelog](CHANGELOG.md)
- [Contributing](CONTRIBUTING.md)